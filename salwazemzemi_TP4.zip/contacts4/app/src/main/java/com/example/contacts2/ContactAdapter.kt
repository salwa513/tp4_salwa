package com.example.contacts2

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.contacts2.databinding.ItemContactBinding
import java.io.File

class ContactAdapter(
    private val onClick: (Contact) -> Unit
) : RecyclerView.Adapter<ContactAdapter.VH>() {

    private var items: List<Contact> = emptyList()
    var taillePoliceSp: Float = 16f
    var couleurTexte: Int = 0xFF000000.toInt()
    var afficherBoutonAppel: Boolean = false

    fun submit(list: List<Contact>) {
        items = list
        notifyDataSetChanged()
    }

    inner class VH(val b: ItemContactBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemContactBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val c = items[position]
        val context = holder.itemView.context

        holder.b.tvNomPrenom.text = "${c.nom} ${c.prenom}"
        holder.b.tvTel.text = c.telephone

        // Appliquer taille et couleur préférées
        holder.b.tvNomPrenom.setTextSize(TypedValue.COMPLEX_UNIT_SP, taillePoliceSp)
        holder.b.tvTel.setTextSize(TypedValue.COMPLEX_UNIT_SP, (taillePoliceSp - 2).coerceAtLeast(12f))

        holder.b.tvNomPrenom.setTextColor(couleurTexte)

        // Photo
        val p = c.photoUri
        if (p != null && File(p).exists()) {
            holder.b.ivPhoto.setImageURI(Uri.fromFile(File(p)))
        } else {
            holder.b.ivPhoto.setImageResource(R.drawable.ic_contact)
        }

        // Clic sur l'élément ouvre le détail
        holder.b.root.setOnClickListener { onClick(c) }

        // Bouton d'appel rapide selon les préférences
        if (afficherBoutonAppel) {
            holder.b.btnAppelerItem.visibility = View.VISIBLE
            holder.b.btnAppelerItem.setOnClickListener {
                val tel = c.telephone.trim()
                if (tel.isEmpty()) {
                    Toast.makeText(context, "Numéro vide", Toast.LENGTH_SHORT).show()
                } else {
                    try {
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(tel)}"))
                        context.startActivity(intent)
                    } catch (e: ActivityNotFoundException) {
                        Toast.makeText(context, "Aucune application téléphone", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        } else {
            holder.b.btnAppelerItem.visibility = View.GONE
            holder.b.btnAppelerItem.setOnClickListener(null)
        }
    }

    override fun getItemCount() = items.size
}
